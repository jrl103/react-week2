import React, { useEffect } from "react";
import styled from "styled-components";
import { useHistory } from "react-router-dom";
import Fab from "@mui/material/Fab";
import AddIcon from "@mui/icons-material/Add";
import { createBucket, loadBucketFB, addBucketFB } from "./redux/modules/word";
import { useDispatch } from "react-redux";

import AddPage from "./AddPage";
import { loadWordFB } from "./redux/modules/word";

const Main = (props) => {
  const word_list = props.word;
  const history = useHistory();
  const dispatch = useDispatch();

  React.useEffect(() => {
    dispatch(loadWordFB());
  }, []);

  return (
    <Wrap>
      <Title>MY DICTIONARY</Title>
      <CardWrap>
        {word_list.map((list, idx) => {
          return (
            <CardBox key={idx}>
              <CardContent>
                <CardTitle>단어</CardTitle>
                <CardText>{list.word}</CardText>
              </CardContent>
              <CardContent>
                <CardTitle>설명</CardTitle>
                <CardText>{list.desc}</CardText>
              </CardContent>
              <CardContent>
                <CardTitle>예시</CardTitle>
                <CardText style={{ color: "blue" }}>{list.ex}</CardText>
              </CardContent>
            </CardBox>
          );
        })}
      </CardWrap>

      <Fab
        onClick={() => {
          history.push("/addpage");
        }}
        color="primary"
        aria-label="add"
      >
        <AddIcon />
      </Fab>
    </Wrap>
  );
};

const Wrap = styled.div`
  background-color: aquamarine;
  padding: 16px;
  width: 100vw;
  height: 100vh;
`;
const Title = styled.h1``;
const CardWrap = styled.div``;
const CardBox = styled.div`
  background-color: #fff;
  width: 80rem;
  height: 15rem;
  padding: 16px;
`;
const CardContent = styled.div``;
const CardTitle = styled.h2`
  text-decoration: underline;
  font-size: 13px;
`;

const CardText = styled.p`
  font-weight: bold;
  font-size: 20px;
`;
// const Button = styled.div`
//   position: "absolute";
//   bottom: 0;
//   right: 0;
// `;
export default Main;
