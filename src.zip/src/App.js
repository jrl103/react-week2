import React from "react";
import styled from "styled-components";
import { BrowserRouter, Route, Switch } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";

import Main from "./Main";
import AddPage from "./AddPage";

function App() {
  const [word, setword] = React.useState([
    {
      word: "사과",
      desc: "red",
      ex: "사과는 빨개.",
    },
    {
      word: "메론",
      desc: "green",
      ex: "메론은 초록색임.",
    },
    {
      word: "복숭아",
      desc: "pink",
      ex: "복숭아는 핑크핑크함.",
    },
  ]);

  return (
    <div>
      <BrowserRouter>
        <Switch>
          <Route path="/" exact component={<Main word={word} />}></Route>
          <Route path="/addpage" exact>
            <AddPage />
          </Route>
        </Switch>
      </BrowserRouter>
    </div>
  );
}

export default App;
