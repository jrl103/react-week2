import React from "react";
import styled from "styled-components";
import { useHistory } from "react-router-dom";

const AddPage = (props) => {
    const word = React.useRef(null);
    const desc = React.useRef(null);
    const ex = React.useRef(null);

  return (
    <Wrap>
      <Title>단어 추가하기</Title>
      <InputWrap>
        <InputBox>
          <InputTitle>단어</InputTitle>
          <input type="text" ref={word}/>
        </InputBox>
        <InputBox>
          <InputTitle>설명</InputTitle>
          <input type="text" ref={desc}/>
        </InputBox>
        <InputBox>
          <InputTitle>예시</InputTitle>
          <input type="text" ref={ex}/>
        </InputBox>
      </InputWrap>
      <AddButton>추가하기</AddButton>
    </Wrap>
  );
};

const Wrap = styled.div`
  background-color: aquamarine;
  padding: 16px;
  width: 100vw;
  height: 100vh;
`;
const Title = styled.h1``;
const InputWrap = styled.div``;
const InputBox = styled.div`
  background-color: #fff;
  width: 80rem;
  height: 10rem;
  padding: 16px;
`;
const InputTitle = styled.h2`
  text-decoration: underline;
  font-size: 13px;
`;
const AddButton = styled.button`
  color: #fff;
  background-color: blue;
  width: 80vw;
  height: 10vh;
  padding: 16px;
`;
export default AddPage;
