// card.js
import { db } from "../../firebase";
import { collection, doc, getDoc, getDocs, addDoc } from "firebase/firestore";

// Action
const LOAD = "word/LOAD";
const CREATE = "word/CREATE";

const initialState = {
  // is_loaded: false,
  list: [
    {
      word: "사과",
      desc: "red",
      ex: "사과는 빨개.",
    },
    {
      word: "메론",
      desc: "green",
      ex: "메론은 초록색임.",
    },
    {
      word: "복숭아",
      desc: "pink",
      ex: "복숭아는 핑크핑크함.",
    },
  ],
};

// Action Creators

export function createWord(word) {
  //   console.log("액션을 생성할거야!");
  return { type: CREATE, word };
}

export function loadWord(word_list) {
  return { type: LOAD, word_list };
}

// middlewares
export const loadWordFB = () => {
  return async function (dispatch) {
    const word_data = await getDocs(collection(db, "word"));
    //   console.log(bucket_data);

    let word_list = [];

    word_data.forEach((b) => {
      console.log(b.data());
      word_list.push({ id: b.id, ...b.data() });
    });

    //   console.log(word_list);

    dispatch(loadWord(word_list));
  };
};

export const addWordFB = (word) => {
  return async function (dispatch) {
    dispatch();
    const docRef = await addDoc(collection(db, "word"), word);
    const word_data = { id: docRef.id, ...word };

    dispatch(createWord(word_data));
  };
};

// Reducer
export default function reducer(state = initialState, action = {}) {
  switch (action.type) {
    case "word/LOAD": {
      return { list: action.word_list };
    }
    case "word/CREATE": {
      // console.log("이제 값을 바꿀거야!");
      const new_word_list = [...state.list, action.word];
      return { ...state, list: new_word_list };
    }
    default:
      return state;
  }
}
